package com.example.mareeswaran_m.bixolonconnectsample;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.mareeswaran_m.bixolonconnectsample.bixolon.PrinterConnectivityListener;
import com.example.mareeswaran_m.bixolonconnectsample.bixolon.PrinterMSRHandler;

public class PrinterStatusActivity extends Activity implements PrinterConnectivityListener {

    private PrinterMSRHandler mPrinterHandler;

    private TextView mStatusText;
    private EditText mEditDelay;
    private Button mConnectButton;

    private TextView mRetryCountTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_status);

        mStatusText = (TextView) findViewById(R.id.printerStatusTxt);
        mEditDelay = (EditText) findViewById(R.id.editDelay);
        mConnectButton = (Button) findViewById(R.id.connectButton);
        mRetryCountTxt = (TextView) findViewById(R.id.retryCountTxt);

        Bundle extras = getIntent().getExtras();
        String address = "";
        if (extras != null) {
            address = extras.getString("address");
        }

        Log.e("MSR", "PrinterHandler...address......"+address);
        mPrinterHandler = new PrinterMSRHandler(this, address, this);
        mConnectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int retry = 5000;
                try {
                    retry = Integer.parseInt(mEditDelay.getText().toString());
                }catch (Exception e){

                }
                mPrinterHandler.setRetryTime(retry);
                mPrinterHandler.connectPrinterByBluetooth();
            }
        });
    }

    @Override
    public void onConnected() {
        Log.e("MSR", "....  ....connected....");
        mStatusText.setText("Printer is Connected");
    }

    @Override
    public void onConnecting() {
        Log.e("MSR", "....  ....connecting....");
        mStatusText.setText("Printer is Connecting..");
    }

    @Override
    public void onConnectionFailed() {
        Log.e("MSR", ".... Bixolon ....connection is none....");
        mStatusText.setText("Printer Connection is Failed");
    }

    @Override
    public void onPrinterNotFound() {
        Log.e("MSR", ".... Bixolon....No paired printer is found....");
        // Toast.makeText(this, "No paired printer is found", Toast.LENGTH_SHORT).show();
        mStatusText.setText("No Printer found in paired list");

    }

    @Override
    public void onRetryCounting(int count) {
        Log.e("MSR", ".... Bixolon ....connect API Called....");
        mRetryCountTxt.setText("Retry Count: " + count);
    }
}
