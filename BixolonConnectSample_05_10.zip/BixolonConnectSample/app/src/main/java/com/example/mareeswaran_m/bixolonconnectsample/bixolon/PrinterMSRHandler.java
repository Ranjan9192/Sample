package com.example.mareeswaran_m.bixolonconnectsample.bixolon;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.bixolon.printer.BixolonPrinter;

import java.util.Set;

/**
 * Created by Sakthikala_P on 2/18/2016.
 */
public class PrinterMSRHandler {

    private static String TAG = PrinterMSRHandler.class.getSimpleName();

    private int retryAttempts;

    String targetPrinterAddress;

    private static int RETRY_DELAY = 5000;

    private BixolonPrinter mBixolonPrinter;

    private Context mContext;

    static private boolean mIsConnected;

    private boolean isRetryConnectionAllowed = true;

    private PrinterConnectivityListener mConnectionListener;

    Handler retryHandler = new Handler();

    public PrinterMSRHandler(Context context, String targetAddress, PrinterConnectivityListener connectionListener){
        mContext = context;
        mConnectionListener = connectionListener;
        Log.e("MSR", "PrinterHandler...Constructor......"+targetAddress);
        mIsConnected = false;
        targetPrinterAddress = targetAddress;
        mBixolonPrinter = new BixolonPrinter(mContext, mHandler, null);
    }

    public void setRetryTime(int retry){
        Log.e("MSR", "PrinterHandler...setRetryTime......"+retry);
        RETRY_DELAY = retry;
    }

    public void connectPrinterByBluetooth(){
        Log.e("MSR", "findBluetoothPrinters.........");
        cancelRetryConnection();
        mBixolonPrinter.findBluetoothPrinters();
        retryConnection();
    }

    public void disconnectPrinter(){
        mIsConnected = false;
        mBixolonPrinter.automateStatusBack(false);
        mBixolonPrinter.disconnect();
    }

    public boolean isConnected(){
        return mIsConnected;
    }

    private void retryConnection(){
        retryHandler.postDelayed(retryTask, RETRY_DELAY);
    }

    private void cancelRetryConnection(){
        retryHandler.removeCallbacks(retryTask);
    }



    private Runnable retryTask =  new Runnable() {
        @Override
        public void run() {
            if(!mIsConnected) {
                mBixolonPrinter.disconnect();
                mHandler = null;
                mHandler = new Handler(mHanlderCallback);
                mBixolonPrinter = new BixolonPrinter(mContext, mHandler, null);
                connectPrinterByBluetooth();
            }
        }
    };

    Handler.Callback mHanlderCallback = new Handler.Callback() {

        @SuppressWarnings("unchecked")
        @Override
        public boolean handleMessage(Message msg) {

            Log.d(TAG, "mHandler.handleMessage(" + msg + ")");
            Log.e("MSR", "mHandler.....");
            Log.e("MSR", "switch ...msg.what.."+msg.what);
            switch (msg.what) {

                case BixolonPrinter.MESSAGE_STATE_CHANGE:
                    Log.e("MSR", "mHandler....case.....MESSAGE_STATE_CHANGE.....");
                    switch (msg.arg1) {
                        case BixolonPrinter.STATE_CONNECTED:
                            Log.e("MSR", "mHandler....case.....STATE_CONNECTED.....");
                            mIsConnected = true;
                            retryAttempts = 0;
                            mConnectionListener.onRetryCounting(retryAttempts);

                            mConnectionListener.onConnected();
                            //Toast.makeText(mContext,"Printer is Connected", Toast.LENGTH_SHORT).show();
                            cancelRetryConnection();

                            break;

                        case BixolonPrinter.STATE_CONNECTING:
                            //  Toast.makeText(mContext,"Printer is Connecting", Toast.LENGTH_SHORT).show();
                            mConnectionListener.onConnecting();
                            break;

                        case BixolonPrinter.STATE_NONE:
                            Log.e("MSR", "mHandler....case.....STATE_NONE.....");
                            mIsConnected = false;
                            mConnectionListener.onConnectionFailed();
                            //  Toast.makeText(mContext,"Printer is Disconnected", Toast.LENGTH_SHORT).show();
                            cancelRetryConnection();
                                retryConnection();

                            break;
                    }
                    return true;


                case BixolonPrinter.MESSAGE_READ:
                    Log.e("MSR","case MESSAGE_READ:");
                    dispatchMessage(msg);
                    return true;



                case BixolonPrinter.MESSAGE_BLUETOOTH_DEVICE_SET:
                    if (msg.obj == null) {
                        Log.e("MSR", "mHandler....case.....msg.obj == null.....");

                    } else {
                        connectPrinter((Set<BluetoothDevice>) msg.obj);
                    }
                    return true;

                case BixolonPrinter.MESSAGE_TOAST:
                    Log.e("MSR", "mHandler....case.....MESSAGE_TOAST....."+msg.getData().getString(BixolonPrinter.KEY_STRING_TOAST));

                    return true;

                case BixolonPrinter.MESSAGE_PRINT_COMPLETE:
                    Log.e("Bitmap", "MESSAGE_PRINT_COMPLETE ... " + System.currentTimeMillis());
                    return true;

                case BixolonPrinter.MESSAGE_ERROR_INVALID_ARGUMENT:
                    Log.e("MSR", "mHandler....case.....MESSAGE_ERROR_INVALID_ARGUMENT.....");
                    return true;

                case BixolonPrinter.MESSAGE_ERROR_NV_MEMORY_CAPACITY:
                    Log.e("MSR", "mHandler....case.....MESSAGE_ERROR_NV_MEMORY_CAPACITY.....");
                    return true;

                case BixolonPrinter.MESSAGE_ERROR_OUT_OF_MEMORY:
                    Log.e("MSR", "mHandler....case.....MESSAGE_ERROR_OUT_OF_MEMORY.....");
                    return true;


            }
            return false;
        }
    };

    private Handler mHandler = new Handler(mHanlderCallback);


    private void dispatchMessage(Message msg) {
        switch (msg.arg1) {
            case BixolonPrinter.PROCESS_GET_STATUS:{
                break;
            }
        }
    }

    private  void connectPrinter(final Set<BluetoothDevice> pairedDevices) {
        Log.e("MSR", "........connectPrinter..isRetryConnectionAllowed..."+isRetryConnectionAllowed);
            Log.e("MSR", "........connectPrinter..targetPrinterAddress..."+targetPrinterAddress);
            for (BluetoothDevice device : pairedDevices) {
                Log.e("MSR", "........connectPrinter...device....." + device.getAddress());

                if (targetPrinterAddress != null && targetPrinterAddress.equalsIgnoreCase(device.getAddress())) {
                    Log.e("MSR", "..connectPrinter......target printer found....." + device.getAddress());
                    Log.e("MSR", "..connectPrinter......cpnnect API...attempts.." + retryAttempts);
                    mBixolonPrinter.connect(device.getAddress());
                    mConnectionListener.onRetryCounting(retryAttempts++);
                    return;
                }

            }

        mConnectionListener.onPrinterNotFound();
        }

}
