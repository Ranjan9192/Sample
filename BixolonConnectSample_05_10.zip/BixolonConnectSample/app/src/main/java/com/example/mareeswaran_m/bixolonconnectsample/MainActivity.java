package com.example.mareeswaran_m.bixolonconnectsample;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class MainActivity extends Activity {

    private ListView mPairedList;

    ArrayList<String> pairedDeviceList;

    private BluetoothAdapter mBluetoothAdapter;

    private TextView mPairedListStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mPairedList = (ListView) findViewById(R.id.pairedList);
        mPairedListStatus = (TextView) findViewById(R.id.listStatus);

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if(mBluetoothAdapter == null){
            Toast.makeText(this, "Device does not support Bluetooth", Toast.LENGTH_SHORT).show();
            finish();
        }

        if(!mBluetoothAdapter.isEnabled()){
            Toast.makeText(this, "Please enable Bluetooth and retry", Toast.LENGTH_SHORT).show();
            finish();
        }

        pairedDeviceList = getPairedDeviceList();

        if(pairedDeviceList != null &&  pairedDeviceList.size()>0) {
            ArrayAdapter<String> pairedDeviceListAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, pairedDeviceList);
            mPairedList.setAdapter(pairedDeviceListAdapter);
        }
        else{
            mPairedListStatus.setText("No paired bluetooth device is available");
            Toast.makeText(this, "No paired bluetooth device is available", Toast.LENGTH_SHORT).show();
        }

        mPairedList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(pairedDeviceList!=null){
                    String bluetoothAddress = pairedDeviceList.get(position);
                    moveToStatusScreen(bluetoothAddress);
                }
            }
        });
    }

    private ArrayList<String> getPairedDeviceList(){
        ArrayList<String> pairedList = new ArrayList<String>();
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if (pairedDevices == null || pairedDevices.size() == 0) {
            return null;
        } else {
            Iterator<BluetoothDevice> devices = pairedDevices.iterator();
            while (devices.hasNext()) {
                BluetoothDevice device = devices.next();
                pairedList.add(device.getAddress());
            }
            return pairedList;
        }
    }

    private void moveToStatusScreen(String bluetoothAddress){
        Intent intent = new Intent(this, PrinterStatusActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString("address", bluetoothAddress);
        intent.putExtras(bundle);
        startActivity(intent);
        finish();
    }

}
