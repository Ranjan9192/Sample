package com.example.mareeswaran_m.bixolonconnectsample.bixolon;

/**
 * Created by sakthikala_P on 2/23/2016.
 */
public interface PrinterConnectivityListener {
    void onConnected();
    void onConnecting();
    void onConnectionFailed();
    void onPrinterNotFound();
    void onRetryCounting(int count);
}
